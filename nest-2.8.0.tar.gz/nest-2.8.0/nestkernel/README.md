# `nestkernel` folder

Classes that make up the bare-bone simulation kernel of NEST without any models.
