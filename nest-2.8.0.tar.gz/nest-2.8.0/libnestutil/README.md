# `libnestutil` folder

General purpose auxiliary library used by SLI and NEST. This library contains the memory allocator and helpers for handling threads, debugging, numerics and reference counted pointers. This directory basically contains all files that do not fit anywhere else.
