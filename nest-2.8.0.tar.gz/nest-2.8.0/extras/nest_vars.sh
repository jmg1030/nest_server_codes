#!/bin/bash

export NEST_INSTALL_DIR=/home/jochen/opt/nest
export PYTHONPATH=$NEST_INSTALL_DIR/lib/python2.7/site-packages:$PYTHONPATH
export PYTHONPATH=$NEST_INSTALL_DIR/lib64/python2.7/site-packages:$PYTHONPATH
export PATH=$NEST_INSTALL_DIR/bin:$PATH
